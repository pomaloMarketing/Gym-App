function AboutUsPage() {
  return (
    <div>
      <h1>About Us</h1>
      <p>The Gym for Her is a women-only gym focused on empowering women through fitness and community.</p>
    </div>
  );
}

export default AboutUsPage;
